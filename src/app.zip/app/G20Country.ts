export class G20Country{
    name: string;
    capital: string;
}